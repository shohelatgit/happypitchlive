import React, { useState } from 'react';
interface BaseComponentProps {
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
const COLORS = {
  black: 'rgba(0, 0, 0, 1)',
  white: 'rgba(255, 255, 255, 1)',
  grayText: 'rgba(124, 124, 124, 1)',
  lightGrayBg: 'rgba(240, 240, 240, 1)',
  borderGray: 'rgba(232, 232, 232, 1)',
  darkGray: 'rgba(28, 28, 28, 1)',
  offWhite: 'rgba(247, 247, 247, 1)'
};
const FONTS = {
  inter: '"Inter", sans-serif'
};

// Reusable Button Component
const ActionButton = ({
  variant = 'primary',
  children,
  icon,
  onClick,
  style
}: {
  variant?: 'primary' | 'secondary' | 'ghost';
  children: React.ReactNode;
  icon?: string;
  onClick?: () => void;
  style?: React.CSSProperties;
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const baseStyle: React.CSSProperties = {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: '16px 24px',
    gap: '16px',
    borderRadius: '990px',
    cursor: 'pointer',
    fontFamily: FONTS.inter,
    fontSize: '18px',
    fontWeight: 600,
    lineHeight: '21.8px',
    transition: 'all 0.2s ease',
    border: 'none',
    ...style
  };
  const variants = {
    primary: {
      backgroundColor: COLORS.black,
      color: COLORS.white,
      transform: isHovered ? 'translateY(-2px)' : 'none',
      boxShadow: isHovered ? '0 4px 12px rgba(0,0,0,0.15)' : 'none'
    },
    secondary: {
      backgroundColor: COLORS.white,
      color: COLORS.black,
      border: `1px solid ${COLORS.borderGray}`,
      transform: isHovered ? 'translateY(-2px)' : 'none',
      boxShadow: isHovered ? '0 4px 12px rgba(0,0,0,0.05)' : 'none'
    },
    ghost: {
      backgroundColor: 'transparent',
      color: COLORS.white,
      padding: '0px'
    }
  };
  return <button onClick={onClick} onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)} style={{
    ...baseStyle,
    ...variants[variant]
  }}>
      {children}
      {icon && <img src={icon} alt="arrow" style={{
      width: '24px',
      height: '24px'
    }} />}
    </button>;
};
const NavItem = ({
  children,
  active = false
}: {
  children: React.ReactNode;
  active?: boolean;
}) => {
  const [isHovered, setIsHovered] = useState(false);
  return <button style={{
    background: 'none',
    border: 'none',
    color: active ? COLORS.darkGray : isHovered ? COLORS.black : COLORS.grayText,
    fontSize: '18px',
    fontFamily: FONTS.inter,
    fontWeight: active ? 500 : 400,
    lineHeight: '27px',
    cursor: 'pointer',
    transition: 'color 0.2s ease',
    padding: '4px 8px'
  }} onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
      {children}
    </button>;
};
export const HeroLandingPage = () => {
  const [activeTab, setActiveTab] = useState('Transaction Readiness');
  const tabs = ['Transaction Readiness', 'Investor Relations', 'Business Development', 'Strategic Positioning'];
  return <div style={{
    width: '100%',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    backgroundColor: COLORS.lightGrayBg,
    boxSizing: 'border-box',
    overflowX: 'hidden',
    position: 'relative'
  }}>
      {/* Navigation Header */}
      <header style={{
      width: '100%',
      maxWidth: '1440px',
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '32px 120px',
      boxSizing: 'border-box'
    }}>
        <img src="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/fdbe1f81-3290-4746-8213-2ffa66130842.png" alt="Logo" style={{
        width: '216px',
        height: '32px',
        objectFit: 'contain'
      }} />
        
        <nav style={{
        display: 'flex',
        gap: '16px',
        alignItems: 'center'
      }}>
          <NavItem active>Home</NavItem>
          <NavItem>Who we serve</NavItem>
          <NavItem>Solutions</NavItem>
          <NavItem>Resources</NavItem>
        </nav>

        <div style={{
        display: 'flex',
        gap: '16px'
      }}>
          <ActionButton variant="primary" style={{
          padding: '8px 16px'
        }} icon="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/c309654f-ff68-4b5b-ad53-30bd67dcaad3.svg">
            Request Samples
          </ActionButton>
          <ActionButton variant="secondary" style={{
          padding: '8px 16px'
        }} icon="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/31cc74db-d2a1-4282-bda5-3c44d7cbaa41.svg">
            Case Studies
          </ActionButton>
        </div>
      </header>

      {/* Hero Section */}
      <section style={{
      width: '100%',
      height: '800px',
      position: 'relative',
      display: 'flex',
      alignItems: 'center',
      padding: '0 120px',
      boxSizing: 'border-box',
      overflow: 'hidden'
    }}>
        <img src="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/adc7c371-3261-4275-8f9e-1b353b4e85de.png" alt="Background" style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        objectFit: 'cover',
        zIndex: 0
      }} />
        <div style={{
        maxWidth: '690px',
        zIndex: 1,
        display: 'flex',
        flexDirection: 'column',
        gap: '40px'
      }}>
          <h1 style={{
          margin: 0,
          fontSize: '80px',
          fontWeight: 700,
          lineHeight: '83.2px',
          letterSpacing: '-2.4px',
          color: COLORS.black,
          fontFamily: FONTS.inter,
          textTransform: 'capitalize'
        }}>
            Clear Stories That<br />Close Deals
          </h1>
          <p style={{
          margin: 0,
          fontSize: '18px',
          lineHeight: '27px',
          color: COLORS.grayText,
          fontFamily: FONTS.inter,
          maxWidth: '580px'
        }}>
            Enable your firm to compete and win across every front with deal-winning narratives that turn complex strategies into capital raises and institutional credibility.
          </p>
          <div style={{
          display: 'flex',
          gap: '16px'
        }}>
            <ActionButton variant="primary" icon="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/3076bda9-6bf7-46f7-812b-dcd56fbe4b15.svg">
              Request Samples
            </ActionButton>
            <ActionButton variant="secondary" icon="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/9989729a-a07e-4c26-bce1-a1023885e8d1.svg">
              Case Studies
            </ActionButton>
          </div>
        </div>
      </section>

      {/* Partners/Logos Section */}
      <section style={{
      width: '100%',
      display: 'flex',
      justifyContent: 'center',
      padding: '80px 120px'
    }}>
        <img src="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/34346a6a-fa74-4deb-b123-cc09ea1a4196.svg" alt="Partners" style={{
        width: '100%',
        maxWidth: '1200px'
      }} />
      </section>

      {/* Solutions Tabs Section */}
      <section style={{
      width: '100%',
      maxWidth: '1440px',
      padding: '120px 120px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '64px',
      boxSizing: 'border-box'
    }}>
        <div style={{
        textAlign: 'center',
        maxWidth: '792px',
        display: 'flex',
        flexDirection: 'column',
        gap: '24px'
      }}>
          <h2 style={{
          fontSize: '56px',
          fontWeight: 700,
          lineHeight: '67.2px',
          letterSpacing: '-1.68px',
          margin: 0
        }}>
            Top providers trusted by growing teams
          </h2>
          <p style={{
          fontSize: '18px',
          color: COLORS.grayText,
          lineHeight: '27px',
          margin: 0
        }}>
            Combining strategic storytelling, deep industry research, and world-class design to turn complex ideas into clear, confident communication.
          </p>
        </div>

        <div style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: '16px',
        width: '100%'
      }}>
          {/* Tabs Container */}
          <div style={{
          display: 'flex',
          padding: '8px',
          gap: '16px',
          backgroundColor: COLORS.black,
          borderRadius: '990px'
        }}>
            {tabs.map(tab => <button key={tab} onClick={() => setActiveTab(tab)} style={{
            padding: '16px 24px',
            borderRadius: '990px',
            border: 'none',
            fontFamily: FONTS.inter,
            fontSize: '16px',
            cursor: 'pointer',
            backgroundColor: activeTab === tab ? COLORS.white : COLORS.darkGray,
            color: activeTab === tab ? COLORS.black : COLORS.white,
            transition: 'all 0.2s ease'
          }}>
                {tab}
              </button>)}
          </div>

          {/* Active Tab Content Card */}
          <div style={{
          width: '100%',
          maxWidth: '996px',
          backgroundColor: COLORS.white,
          borderRadius: '24px',
          padding: '8px',
          boxShadow: '0px 4px 8px rgba(154, 154, 154, 0.24)',
          boxSizing: 'border-box'
        }}>
            <div style={{
            display: 'flex',
            backgroundColor: COLORS.black,
            borderRadius: '16px',
            overflow: 'hidden',
            minHeight: '520px'
          }}>
              <div style={{
              flex: 1,
              padding: '56px 48px',
              display: 'flex',
              flexDirection: 'column',
              gap: '32px'
            }}>
                <h3 style={{
                color: COLORS.white,
                fontSize: '36px',
                fontWeight: 700,
                margin: 0,
                letterSpacing: '-0.36px'
              }}>
                  {activeTab}
                </h3>
                
                <div style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '24px'
              }}>
                  {[{
                  title: 'Investment Memorandums',
                  desc: 'Deal books that secure funding and close acquisitions by presenting clear investment cases backed by data and strategic rationale.'
                }, {
                  title: 'Management Presentations',
                  desc: 'Executive pitch decks that drive M&A processes by articulating company value, market position, and growth potential.'
                }, {
                  title: 'Company Profiles',
                  desc: 'Strategic overviews that position firms for sale, partnership, or investment by highlighting competitive advantages and value drivers.'
                }].map((item, i) => <div key={i} style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '8px'
                }}>
                      <span style={{
                    color: COLORS.white,
                    fontSize: '16px',
                    fontWeight: 400
                  }}>{item.title}</span>
                      <p style={{
                    color: COLORS.grayText,
                    fontSize: '16px',
                    margin: 0,
                    lineHeight: '19.4px'
                  }}>{item.desc}</p>
                    </div>)}
                </div>

                <ActionButton variant="ghost" icon="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/2a1c711b-ed26-4dce-9bc8-e3302c30d472.svg">
                  Explore Solutions
                </ActionButton>
              </div>

              <div style={{
              flex: 1,
              backgroundColor: COLORS.darkGray,
              position: 'relative',
              overflow: 'hidden'
            }}>
                <img src="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/49a7751e-fb3b-4836-9218-7130d71ddf0e.png" alt="Interface mockup" style={{
                position: 'absolute',
                width: '120%',
                top: '10%',
                left: '-10%'
              }} />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid Section */}
      <section style={{
      width: '100%',
      maxWidth: '1440px',
      padding: '120px 120px',
      boxSizing: 'border-box'
    }}>
        <h2 style={{
        fontSize: '56px',
        fontWeight: 700,
        textAlign: 'center',
        marginBottom: '64px',
        letterSpacing: '-1.68px'
      }}>
          Why Choose Collateral Partners?
        </h2>
        
        <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        gap: '24px',
        width: '100%'
      }}>
          {Array(6).fill(null).map((_, i) => <div key={i} style={{
          backgroundColor: COLORS.offWhite,
          padding: '8px',
          borderRadius: '24px',
          boxShadow: '0px 4px 8px rgba(154, 154, 154, 0.24)'
        }}>
              <div style={{
            backgroundColor: COLORS.white,
            padding: '24px',
            borderRadius: '16px',
            height: '100%',
            boxSizing: 'border-box'
          }}>
                <div style={{
              width: '48px',
              height: '48px',
              marginBottom: '16px'
            }}>
                  <img src="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/49d22914-47c3-4a45-9430-97727a848ffc.svg" alt="icon" style={{
                width: '100%'
              }} />
                </div>
                <h4 style={{
              fontSize: '24px',
              fontWeight: 700,
              margin: '0 0 16px 0',
              letterSpacing: '-0.96px'
            }}>Built for Finance</h4>
                <p style={{
              fontSize: '16px',
              color: COLORS.grayText,
              margin: 0,
              lineHeight: '19.4px'
            }}>
                  Deal books that secure funding and close acquisitions by presenting clear investment cases backed by data and strategic rationale.
                </p>
              </div>
            </div>)}
        </div>
      </section>

      {/* Metrics Section */}
      <section style={{
      width: '100%',
      backgroundColor: COLORS.black,
      padding: '120px 120px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '64px',
      boxSizing: 'border-box'
    }}>
        <h2 style={{
        color: COLORS.white,
        fontSize: '56px',
        fontWeight: 700,
        letterSpacing: '-1.68px',
        margin: 0
      }}>
          Chosen By Sophisticated Businesses
        </h2>
        <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        width: '100%',
        maxWidth: '1200px'
      }}>
          {[1, 2, 3].map((_, i) => <div key={i} style={{
          textAlign: 'center',
          display: 'flex',
          flexDirection: 'column',
          gap: '16px'
        }}>
              <span style={{
            color: COLORS.white,
            fontSize: '80px',
            fontWeight: 700,
            letterSpacing: '-2.4px'
          }}>$10B+</span>
              <span style={{
            color: COLORS.grayText,
            fontSize: '18px'
          }}>Capital Represented in Client Projects</span>
            </div>)}
        </div>
      </section>

      {/* Strategic Pillars Section */}
      <section style={{
      width: '100%',
      maxWidth: '1440px',
      padding: '120px 120px',
      boxSizing: 'border-box'
    }}>
        <div style={{
        textAlign: 'center',
        maxWidth: '792px',
        margin: '0 auto 64px auto',
        display: 'flex',
        flexDirection: 'column',
        gap: '24px'
      }}>
          <h2 style={{
          fontSize: '36px',
          fontWeight: 700,
          margin: 0
        }}>Turn Complex Strategies Into Presentations That Close Deals</h2>
          <p style={{
          fontSize: '18px',
          color: COLORS.grayText,
          margin: 0
        }}>
            Real estate funds that closed billion-dollar acquisitions. Private equity firms that raised oversubscribed funds... When the stakes are high, sophisticated firms choose materials that actually work.
          </p>
        </div>

        <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        gap: '24px'
      }}>
          {[{
          title: 'Research',
          icon: 'https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/4884653d-b105-48e8-94be-a6c374245c4a.svg',
          desc: 'Market intelligence that reveals where you win. Deep industry insights and data-backed analysis.'
        }, {
          title: 'Strategy',
          icon: 'https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/7ae41e44-167c-473b-b1b6-00dae643d97c.svg',
          desc: 'Investment theses built on logic and clarity. Messaging frameworks that articulate value.'
        }, {
          title: 'Design',
          icon: 'https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/dae62983-788e-434f-bee1-fbf866749b56.svg',
          desc: 'Sophisticated visuals that match your strategy. Complex ideas transformed into clear presentations.'
        }].map((item, i) => <div key={i} style={{
          backgroundColor: COLORS.offWhite,
          padding: '8px',
          borderRadius: '24px'
        }}>
              <div style={{
            backgroundColor: COLORS.white,
            padding: '24px',
            borderRadius: '16px',
            height: '100%',
            display: 'flex',
            flexDirection: 'column',
            gap: '24px'
          }}>
                <img src={item.icon} alt={item.title} style={{
              width: '48px',
              height: '48px'
            }} />
                <h4 style={{
              fontSize: '24px',
              fontWeight: 700,
              margin: 0
            }}>{item.title}</h4>
                <p style={{
              color: COLORS.grayText,
              fontSize: '16px',
              margin: 0
            }}>{item.desc}</p>
                <div style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '12px',
              marginTop: 'auto'
            }}>
                  {Array(4).fill('Market Intelligence').map((label, j) => <div key={j} style={{
                display: 'flex',
                gap: '8px',
                alignItems: 'center'
              }}>
                      <img src="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/7d836645-589c-450f-b94e-1793a6133cce.svg" alt="check" style={{
                  width: '24px'
                }} />
                      <span style={{
                  fontSize: '16px',
                  color: COLORS.grayText
                }}>{label}</span>
                    </div>)}
                </div>
              </div>
            </div>)}
        </div>
      </section>

      {/* Case Studies Section */}
      <section style={{
      width: '100%',
      maxWidth: '1440px',
      padding: '120px 120px',
      boxSizing: 'border-box'
    }}>
        <h2 style={{
        fontSize: '56px',
        fontWeight: 700,
        textAlign: 'center',
        marginBottom: '64px'
      }}>Trusted By Leading Financial Firms</h2>
        <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        gap: '24px'
      }}>
          {[1, 2, 3].map((_, i) => <div key={i} style={{
          backgroundColor: COLORS.offWhite,
          borderRadius: '24px',
          overflow: 'hidden',
          padding: '8px'
        }}>
              <div style={{
            backgroundColor: COLORS.white,
            padding: '24px',
            display: 'flex',
            flexDirection: 'column',
            gap: '16px'
          }}>
                <div style={{
              backgroundColor: COLORS.lightGrayBg,
              borderRadius: '990px',
              padding: '4px 12px',
              width: 'fit-content',
              fontSize: '14px',
              fontWeight: 700
            }}>Real Estate</div>
                <h4 style={{
              fontSize: '24px',
              fontWeight: 700,
              margin: 0
            }}>Elevate Your Real Estate Marketing Collateral</h4>
                <ActionButton variant="ghost" style={{
              color: COLORS.black
            }} icon="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/c235bec7-60f0-4bea-9a79-e7019e01dab1.svg">
                  Learn More
                </ActionButton>
              </div>
              <div style={{
            padding: '24px',
            backgroundColor: COLORS.black,
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }}>
                <img src="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/926518b2-8aba-4a8b-a2ed-427e28fef90a.png" alt="logo" style={{
              height: '40px'
            }} />
                <img src="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/fb8f04e1-de26-4214-acf1-0300620e50e4.png" alt="icon" style={{
              height: '40px'
            }} />
              </div>
            </div>)}
        </div>
      </section>

      {/* Testimonial Section */}
      <section style={{
      width: '100%',
      maxWidth: '1440px',
      padding: '120px 120px',
      boxSizing: 'border-box'
    }}>
        <div style={{
        backgroundColor: COLORS.white,
        borderRadius: '24px',
        padding: '8px',
        boxShadow: '0px 4px 8px rgba(154, 154, 154, 0.24)'
      }}>
          <div style={{
          display: 'flex',
          backgroundColor: COLORS.black,
          borderRadius: '16px',
          overflow: 'hidden'
        }}>
            <div style={{
            flex: 1.5,
            padding: '64px',
            display: 'flex',
            flexDirection: 'column',
            gap: '40px'
          }}>
              <p style={{
              fontSize: '18px',
              color: COLORS.offWhite,
              lineHeight: '27px',
              margin: 0
            }}>
                "Collateral Partners' research capabilities set them apart—they aggregated bespoke market data and industry intelligence that perfectly supported our investment thesis. Their ability to synthesize complex real estate fundamentals into a compelling fundraising narrative was instrumental in our capital raising success."
              </p>
              <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '30px'
            }}>
                <div>
                  <h5 style={{
                  color: COLORS.white,
                  fontSize: '24px',
                  fontWeight: 700,
                  margin: 0
                }}>Sarah Thomson</h5>
                  <span style={{
                  color: COLORS.grayText,
                  fontSize: '14px'
                }}>Marketing Consultant</span>
                </div>
                <div style={{
                width: '1px',
                height: '44px',
                backgroundColor: COLORS.white,
                opacity: 0.1
              }}></div>
                <img src="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/3c67f4eb-ca91-40c8-8711-8741e0e4a22d.svg" alt="Company Logo" style={{
                height: '44px'
              }} />
              </div>
            </div>
            <div style={{
            flex: 1,
            position: 'relative'
          }}>
              <img src="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/d7138355-84bc-411e-8d1d-2c5322614ec3.png" alt="Sarah Thomson" style={{
              width: '100%',
              height: '100%',
              objectFit: 'cover'
            }} />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section style={{
      width: '100%',
      backgroundColor: COLORS.black,
      padding: '120px 120px',
      position: 'relative',
      overflow: 'hidden',
      boxSizing: 'border-box'
    }}>
        <div style={{
        maxWidth: '588px',
        display: 'flex',
        flexDirection: 'column',
        gap: '40px',
        position: 'relative',
        zIndex: 2
      }}>
          <h2 style={{
          color: COLORS.white,
          fontSize: '56px',
          fontWeight: 700,
          lineHeight: '67.2px',
          margin: 0
        }}>
            Your Next Deal Starts With Better Collateral
          </h2>
          <p style={{
          color: COLORS.grayText,
          fontSize: '22px',
          lineHeight: '26.6px',
          margin: 0
        }}>
            Great strategies get overlooked when they're not presented the right way. Don’t let weak communication cost you the allocation.
          </p>
          <ActionButton variant="secondary" icon="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/08f484d3-ab85-46a5-a080-318ab29fa9f3.svg">
            Book Consultation
          </ActionButton>
        </div>
        <img src="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/6b694e34-9dca-452d-bdb7-e5c0bb118c5b.png" alt="Abstract decorative" style={{
        position: 'absolute',
        right: '-200px',
        top: '-200px',
        width: '1000px',
        opacity: 0.8
      }} />
      </section>

      {/* Footer */}
      <footer style={{
      width: '100%',
      backgroundColor: COLORS.black,
      padding: '80px 120px',
      display: 'flex',
      justifyContent: 'space-between',
      boxSizing: 'border-box',
      borderTop: '1px solid rgba(255,255,255,0.1)'
    }}>
        <div style={{
        maxWidth: '320px',
        display: 'flex',
        flexDirection: 'column',
        gap: '16px'
      }}>
          <img src="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/a35e7cae-f8d8-4d21-93e9-b4919d6e1ddd.png" alt="Footer Logo" style={{
          height: '32px',
          width: 'fit-content'
        }} />
          <p style={{
          color: COLORS.lightGrayBg,
          fontSize: '16px',
          lineHeight: '19.4px',
          margin: 0
        }}>
            Collateral Partners provides financial communications advisory services for finance firms.
          </p>
          <div style={{
          display: 'flex',
          gap: '16px'
        }}>
            <a href="#" style={{
            width: '24px',
            height: '24px'
          }}>
              <img src="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/a10f9783-8d3c-4114-b07a-7374cad5cde9.svg" alt="LinkedIn" />
            </a>
            <a href="#" style={{
            width: '24px',
            height: '24px'
          }}>
              <img src="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/96ea43c3-85ed-48a4-8752-1ac696caec3a.svg" alt="Twitter" />
            </a>
          </div>
        </div>

        <div style={{
        display: 'flex',
        gap: '80px'
      }}>
          <div style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '12px'
        }}>
            <NavItem active>Home</NavItem>
            <NavItem>Who we serve</NavItem>
            <NavItem>Solutions</NavItem>
            <NavItem>Resources</NavItem>
          </div>
          <div style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '12px'
        }}>
            <NavItem>Legal</NavItem>
            <NavItem>Privacy</NavItem>
            <NavItem>Contact</NavItem>
          </div>
        </div>

        <div style={{
        display: 'flex',
        flexDirection: 'column',
        gap: '16px'
      }}>
          <ActionButton variant="secondary" style={{
          padding: '8px 16px'
        }} icon="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/a0aab8e3-4c77-4139-a66e-0f9368e7ebb2.svg">
            Request Samples
          </ActionButton>
          <ActionButton variant="secondary" style={{
          padding: '8px 16px'
        }} icon="https://storage.googleapis.com/storage.magicpath.ai/user/374684919160512512/figma-assets/0fbcf04c-5d3a-42fb-a8c0-8e23d04cf7e4.svg">
            Case Studies
          </ActionButton>
        </div>
      </footer>
    </div>;
};